package com.hx.lxj;

import android.annotation.*;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.view.*;
import android.view.View.*;
import android.view.inputmethod.*;
import android.webkit.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.regex.*;
import java.util.zip.*;
import org.json.*;



@SuppressLint({ "DefaultLocale", "HandlerLeak" })
public class WebView1 extends Activity {
	private WebView webview;
	private Button btn_menu;
	private Button btn_go;
	private EditText et;
	public int load_count = 0;
	private ProgressBar load_pro;
	private String webUrl = "https://weibo.com/u/1650425203";
	//private String url_llq = "";
	private ValueCallback<Uri> mUploadMessage;
	ValueCallback<Uri[]> filePathCallback;
	private final static int FILECHOOSER_RESULTCODE = 1;
	private boolean flag = false;

	//public String mFN = "ip.txt";
	//public String mWWW = "/";
	//public String IP = "";
	//public String host_port = "8181";
	//public String local_host = "";
	//public String localUrl = "";
	//public static String sd_dir = "";
	//public static String sitePath = "";
	//public static int id;
	static final String LILY_TEST_INTENT = "com.hx.hxtestintent2";
	//static final String ID = "id";
	//static final String TIME = "alarm_time";
	//public String wifiinfo = "";
	//public JSONArray NetIp = new JSONArray();
	//public String dfip = "";
	//public Handler handler = null;
	//public Handler handlerPHP = null;
	//public Handler handlerAP = null;
	//public String appDir=null;
	//public String htmlStr = "";

	public Context context;
	
	//LocationBroadcastReceiver broadcastReceiver;
	// ������ַ�򿪽�����
	//LocationBroadcastReceiver2 broadcastReceiver2;

	// ����
	//private static final Intent sSettingsIntent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);


	@SuppressLint({ "SetJavaScriptEnabled", "SdCardPath" })
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.webview1);
		context=this;
		try {
			//-----------------6.0����app�ļ���com.hongxin.wcf------------------
			DirFile.createAppDir();
			//---------------------------���sd��·���Ƿ���ڣ�������ת������ҳ
			
			//sitePath=MySDCard.get_site_path();
			
			//MainFun.checkLLQ();//���llq.html�ļ����ڡ�
			//���ô����ʱ���ҳ��
			//url_llq = "file:///"+sitePath+File.separator+"llq.html";
//		webUrl="file:///"+sitePath+File.separator+"llq.html";
			//��ȡ���ص���ַ
			//LXJ_CS lxjcs=new LXJ_CS();
			//local_host=lxjcs.ip;
			//host_port=lxjcs.port;
			//localUrl="http://"+local_host+":"+host_port;


			load_pro = (ProgressBar) findViewById(R.id.loadpro);
		// et=(EditText)findViewById(R.id.url1);
			webview = (WebView)findViewById(R.id.wv1);
			webview.getSettings().setJavaScriptEnabled(true);
			webview.requestFocus();
			webview.getSettings().setSupportZoom(true);
			webview.getSettings().setUseWideViewPort(true);
			webview.getSettings().setLoadWithOverviewMode(true);
			webview.addJavascriptInterface(new InJavaScriptLocalObj(),
										   "js_on_and");
			webview.setWebViewClient(new HelloWebViewClient());
			webview.setWebChromeClient(new MyWebChromeClient());
			webview.setOnTouchListener(new OnTouchListener() {
					public boolean onTouch(View v, MotionEvent event) {
						webview.requestFocus();
						return false;
					}
				});
			webview.loadUrl(webUrl);
			webview.setVisibility(View.VISIBLE);
			//----------------���ؿؼ�------------------
			btn_menu=(Button)findViewById(R.id.menu1);
			btn_go=(Button)findViewById(R.id.go);
			et=(EditText)findViewById(R.id.url1);
			btn_menu.setOnClickListener(
				new OnClickListener() {

					@Override
					public void onClick(View arg0) {
						open_menu_a();						
					}					
				});
			btn_go.setOnClickListener(
				new OnClickListener() {

					@Override
					public void onClick(View arg0) {
						String url=et.getText().toString();	
						int len=url.length();
						if(len>0)
						{
							String url_text;
							String url_head = "http://";
							url_text = url;
							url_text = url_text.trim();
							if (!url_text.contains("http://")) {
								url_text = url_head.concat(url_text);
							}
							webview.loadUrl(url_text);
							InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
							if (imm.isActive()) {
								imm.hideSoftInputFromWindow(et.getWindowToken(),
															0);
							}							
						}
					}					
				});
			//�����̣߳�������վip
			//createIp();
			//Php.start_php_server(handlerPHP);
		} catch (Exception e) {
		DirFile.err(e);
		}

	}

	
	
	@SuppressLint("ShowToast")
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if ((keyCode == KeyEvent.KEYCODE_BACK) && webview.canGoBack()) {// if1
			webview.goBack();
			// String t=webview.getTitle();
			//et_1.setText(webUrl);
			return true;
		} else if ((keyCode == KeyEvent.KEYCODE_BACK) && !webview.canGoBack()
				   && flag == false) {
			webview.setVisibility(View.GONE);
			load_pro.setVisibility(View.GONE);
			flag = true;
			return true;
		} else if ((keyCode == KeyEvent.KEYCODE_BACK) && !webview.canGoBack()
				   && flag == true) {
			flag = true;
			// SetDialogExit();
			//exitAppDo();
			finish();
			return true;
		}
		return false;
	}

	// [3]����ͼƬ
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == FILECHOOSER_RESULTCODE) {
			if (null == mUploadMessage)
				return;
			Uri result = data == null || resultCode != RESULT_OK ? null : data
				.getData();
			if (result == null) {
				mUploadMessage.onReceiveValue(null);
				mUploadMessage = null;
				return;
			}
			String path = FileUtils.getPath(this, result);
			if (TextUtils.isEmpty(path)) {
				mUploadMessage.onReceiveValue(null);
				mUploadMessage = null;
				return;
			}
			Uri uri = Uri.fromFile(new File(path));
			mUploadMessage.onReceiveValue(uri);
			mUploadMessage = null;
		}
	}

	// [4]��ҳ��Ϊ
	private class HelloWebViewClient extends WebViewClient {

		@SuppressLint("SdCardPath")
		@Override
		public void onPageStarted(WebView view, String url, Bitmap favicon) {
			// if(url.contains(localUrl)){
			// StartPHP();
			// }
			super.onPageStarted(view, url, favicon);
		}

		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url) {
			view.loadUrl(url);
			load_pro.setVisibility(View.VISIBLE);
			// String t=webview.getTitle();
			//			et_1.setText(url);
			return true;
		}

		@Override
		public void onReceivedError(WebView view, int errorCode,
									String description, String failingUrl) {
			/*try {
			 MyHandler.getHandler().postDelayed(new Runnable() {
			 @Override
			 public void run() {
			 if (load_count <= 5) {
			 load_count++;
			 webview.loadUrl(webUrl);
			 webview.setVisibility(View.VISIBLE);
			 } else {
			 webview.loadUrl(url_llq);
			 load_count = 0;
			 }
			 }
			 }, 40);
			 } catch (Exception e) {
			 Err.getErrStr(e);
			 }*/
			super.onReceivedError(view, errorCode, description, failingUrl);

		}

		@Override
		public void onPageFinished(WebView view, String url) {
			// �ڽ��������ҳʱ��ص�

			// ��ȡҳ������
			// MyLog.writeTxtToFile(url+"=="+homeUrl+"?homeurl="+local_host, "",
			// "");
			// if(url.contains("homeurl")){
			// //Toast.makeText(context, "׼������", Toast.LENGTH_SHORT).show();
//			 view.loadUrl("javascript:window.js_on_and.getHtmlStr("
//			 + "document.getElementsByTagName('html')[0].innerHTML);");
			//}

			// ��ȡ����<meta name="share-description" content="��ȡ����ֵ">
			// view.loadUrl("javascript:window.js_on_and.showDescription("
			// +
			// "document.querySelector('meta[name=\"share-description\"]').getAttribute('content')"
			// + ");");
			// et1.setText(webUrl);
			super.onPageFinished(view, url);
		}
	}

	// [5]����ͼƬ
	public class MyWebChromeClient extends WebChromeClient {
		// For Android 3.0+
		public void openFileChooser(ValueCallback<Uri> uploadMsg,
									String acceptType) {
			if (mUploadMessage != null)
				return;
			mUploadMessage = uploadMsg;
			Intent i = new Intent(Intent.ACTION_GET_CONTENT);
			i.addCategory(Intent.CATEGORY_OPENABLE);
			i.setType("*/*");
			startActivityForResult(Intent.createChooser(i, "File Chooser"),
								   FILECHOOSER_RESULTCODE);
		}

		// For Android < 3.0
		public void openFileChooser(ValueCallback<Uri> uploadMsg) {
			openFileChooser(uploadMsg, "");
		}

		// For Android > 4.1.1
		public void openFileChooser(ValueCallback<Uri> uploadMsg,
									String acceptType, String capture) {
			if (mUploadMessage != null) {
				mUploadMessage.onReceiveValue(null);
			}
			mUploadMessage = uploadMsg;
			Intent i = new Intent(Intent.ACTION_GET_CONTENT);
			i.addCategory(Intent.CATEGORY_OPENABLE);
			String type = TextUtils.isEmpty(acceptType) ? "*/*" : acceptType;
			i.setType(type);
			startActivityForResult(Intent.createChooser(i, "File Chooser"),
								   FILECHOOSER_RESULTCODE);
		}

		@Override
		public void onProgressChanged(WebView view, int newProgress) {
			// Toast.makeText(context,newProgress+"%", 0).show();
			if (newProgress == 100) {// if1
				load_pro.setVisibility(View.GONE);
				// String t=webview.getTitle();
				et.setText(view.getUrl().toString());
			} else {
				if (load_pro.getVisibility() == View.GONE)
					load_pro.setVisibility(View.VISIBLE);
				load_pro.setProgress(newProgress);
			}
		}// onProgressChanged

	}

	/*
	 * 
	 * [6]�˵�
	 */
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		int MENU_ITEM_COUNTER = 0;
		menu.add(0, MENU_ITEM_COUNTER, 0, "主页");
		menu.add(0, MENU_ITEM_COUNTER + 1, 0, "刷新");
		menu.add(0, MENU_ITEM_COUNTER + 2, 0, "后退");
		menu.add(0, MENU_ITEM_COUNTER + 3, 0, "前进");
		menu.add(0, MENU_ITEM_COUNTER + 4, 0,"录像机");
		menu.add(0, MENU_ITEM_COUNTER + 5, 0, "分享");
		menu.add(0, MENU_ITEM_COUNTER + 6, 0, "退出");
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		
	}

	/*
	 * 
	 * [7]�򿪲˵�����
	 */
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		try {
			switch (item.getItemId()) {
				case 0: 
					webview.post(new Runnable() {
							@Override
							public void run() {
								webview.loadUrl(webUrl);
								webview.setVisibility(View.VISIBLE);
							}
						});
					break;
				case 1: 
					webview.post(new Runnable() {
							@Override
							public void run() {
								webview.reload();
								webview.setVisibility(View.VISIBLE);
							}
						});

					break;
				case 2:
					webview.post(new Runnable() {
							@Override
							public void run() {
								webview.goBack();
							}
						});

					break;
				case 3:
					webview.post(new Runnable() {
							@Override
							public void run() {
								webview.goForward();
							}
						});

					break;
				
				case 4: //
					Intent i = new Intent(this, MainActivity.class);
					startActivity(i);
					this.finish();
					break;
				
				case 5: //
				fx();
					/*new Thread(new Runnable() {
							@Override
							public void run() {
								hxShare(webview);
							}
						});
*/
					break;
				case 6: //
					exitAppDo();
					break;
				
				default:
					webview.post(new Runnable() {
							@Override
							public void run() {
								webview.loadUrl(webUrl);
								webview.setVisibility(View.VISIBLE);
							}
						});

					break;
			}
			return super.onOptionsItemSelected(item);
		} catch (Exception e) {
			DirFile.err(e);
		}
		return false;
	}

	/*########################
	 * 
	 * ����
	 * 
	 * ######################*/	
	 private void fx(){
		 String t = webview.getTitle();
		 String u = webview.getUrl();
		 Intent textIntent = new Intent(Intent.ACTION_SEND);
		 textIntent.setType("text/plain");
		 textIntent.putExtra(Intent.EXTRA_TEXT, "来自后台录像机："+t+u);
		 startActivity(Intent.createChooser(textIntent, "分享"));
	 }
	
	
	



	/*########################
	 * 
	 * 	�򿪲˵�
	 * 
	 * ######################*/	
	public boolean open_menu_a() {
		super.openOptionsMenu();
		return true;
	}

	/*########################
	 * 
	 * js�ӿ�
	 * 
	 * ######################*/	
	public final class InJavaScriptLocalObj {

		
		
		// ��3���򿪲˵�
		@JavascriptInterface
		public void openMenu() {
			open_menu_a();
		}

		

		// ��5�������
		@JavascriptInterface
		public void openLXJ() {
			openLXJDo();
		}

		

		
		

		
		


		@JavascriptInterface
		public void stopLX() {
			stopLX2();
		}

		

		
		@JavascriptInterface
		public void openLXList() {
			openLXList2();
		}

		// ��9���˳�app
		@JavascriptInterface
		public void exitApp() {
			exitAppDo();

		}

		
		

		@JavascriptInterface
		public void url_go(String url) {
			url_go_a(url);
		}

		

		

		
		
		

	
		
	}
	
	private void openLXList2() {
		try {
			webview.post(new Runnable() {
					@Override
					public void run() {
//					LXJ_CS lxjcs=new LXJ_CS();
//					int nck=lxjcs.getnck();
//					int ncs=0;
//					if(nck>=0){
//						ncs=nck;
//					}
						String videoPath = DirFile.getVideoPath();
						Intent intent = new Intent();
						intent.putExtra("path", videoPath);
						intent.setClass(WebView1.this, FileList.class);
						startActivity(intent);
					}
				});
		} catch (Exception e) {
		DirFile.err(e);
		}
	}

	/*########################
	 * 
	 * �����
	 * 
	 * ######################*/	
	private void openLXJDo() {
		try {
			webview.post(new Runnable() {
					@Override
					public void run() {
						startAlarm();
					}
				});
		} catch (Exception e) {
			DirFile.err(e);
		}
	}
	/*########################
	 * 
	 * �����
	 * 
	 * ######################*/	
	private void startAlarm() {
		// stopAlarm();
		// star service
		Intent intent2 = new Intent(WebView1.this, Server.class);
		startService(intent2);
		// start alarm
		int id = 1;
		AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
		Intent intent = new Intent(LILY_TEST_INTENT);
		intent.setData(Uri.parse("content://calendar/calendar_alerts/1"));
		intent.setClass(this, Receiver.class);
		intent.putExtra("ID", id);
		long atTimeInMillis = System.currentTimeMillis();
		intent.putExtra("TIME", atTimeInMillis);
		// intent.putExtra(LABEL, label);
		// intent.putExtra(TIME, atTimeInMillis);
		PendingIntent sender = PendingIntent.getBroadcast(this, 0, intent,
														  PendingIntent.FLAG_CANCEL_CURRENT);
		// am.set(AlarmManager.RTC_WAKEUP, atTimeInMillis, sender);
		am.setRepeating(AlarmManager.ELAPSED_REALTIME,
						SystemClock.elapsedRealtime(), 15 * 1000, sender);
		
		// Toast.makeText(Home.this, "��ʼ����", Toast.LENGTH_SHORT).show();
	}
	/*########################
	 * 
	 * ֹͣ���
	 * 
	 * ######################*/	
	private void stopLX2() {
		try {
			webview.post(new Runnable() {
					@Override
					public void run() {
						stopAlarm();
					}
				});
		} catch (Exception e) {
			DirFile.err(e);
		}
	}
	/*########################
	 * 
	 * ֹͣ���
	 * 
	 * ######################*/	
	private void stopAlarm() {

		int id = 2;

		Intent intent2 = new Intent(WebView1.this, Server.class);
		stopService(intent2);
		AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
		Intent intent = new Intent(LILY_TEST_INTENT);
		intent.setClass(this, Receiver.class);
		intent.putExtra("ID", id);
		intent.setData(Uri.parse("content://calendar/calendar_alerts/1"));
		// id = 2;
		// Log.i("lily","id = 2");
		// intent.putExtra(ID, id);
		PendingIntent sender = PendingIntent.getBroadcast(this, 0, intent,
														  PendingIntent.FLAG_NO_CREATE);
		if (sender != null) {
			am.cancel(sender);
			Toast.makeText(WebView1.this, "stop", Toast.LENGTH_SHORT).show();
		}
		ActivityManager activityMgr = (ActivityManager) this
			.getSystemService(ACTIVITY_SERVICE);
		activityMgr.killBackgroundProcesses(getPackageName());
		android.os.Process.killProcess(android.os.Process.myPid());
		// ActivityManager manager =
		// (ActivityManager)getSystemService(Context.ACTIVITY_SERVICE);
		// manager.killBackgroundProcesses("com.hongxin.wcf");
	}

	

	
	

	// [15]�˳�app
	private void exitAppDo() {
		this.finish();
	}


	

	// ��FTP
	// [19]ת����ַ
	private void url_go_a(final String url) {
		// Toast.makeText(llq.this, url, Toast.LENGTH_SHORT).show();
		try {
			webview.post(new Runnable() {
					@Override
					public void run() {
						if (!url.equals("")) {
							String url_text;
							String url_head = "http://";
							url_text = url;
							// �����û�[����]
							String regEx = "\\[(.+?)\\]";
							Pattern p = Pattern.compile(regEx);
							Matcher m = p.matcher(url_text);
							url_text = m.replaceAll("").trim();
							// Log.i("url", url_text);
							if (!url_text.contains("http://")) {
								url_text = url_head.concat(url_text);
							}
							// �����������ַ
							webview.loadUrl(url_text);
							// �����������
							InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
							if (imm.isActive()) {
								imm.hideSoftInputFromWindow(
									webview.getWindowToken(), 0);
							}
						}
					}
				});
		} catch (Exception e) {
			DirFile.err(e);
		}

	}

	

	

	
	public void openUrl2(final String url) {
		webview.post(new Runnable() {
				@Override
				public void run() {
					webview.loadUrl(url);
					webview.setVisibility(View.VISIBLE);
				}
			});
	}
	

}
