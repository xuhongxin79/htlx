package com.hx.lxj;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class SelectDir extends Activity{
	private List<String> items = null;//文件名
	private List<String> paths = null;//路径
	private static String rootPath = "/";
	private static String curPath = DirFile.SDDir();
	private TextView mPath;//路径展示
	private Button mOkButton;//保存路径按钮
	private ListView lv;//文件和文件夹展示
	

	@Override
	protected void onCreate(Bundle icicle) {
		super.onCreate(icicle);
		setContentView(R.layout.pathselect);
		
		mPath = (TextView) findViewById(R.id.pathselectTextView);
		mOkButton = (Button) findViewById(R.id.pathselectButton);
		
		Button buttonCancle = (Button) findViewById(R.id.pathselectButton2);
		
		lv=(ListView)findViewById(R.id.pathselectListView);
		curPath = PreferenceUtils.getPrefString(this,CL.APPDIRKEY, DirFile.SDDir());
		//curPath=MySDCard.getAPPPathFromSet();
		getFileDir(curPath);
		
	}

	private void getFileDir(String filePath) {
		//BaseApplication.ts(filePath);
		mPath.setText(filePath);
		items = new ArrayList<String>();
		paths = new ArrayList<String>();
		File f = new File(filePath);
		File[] files = f.listFiles();
		boolean root = filePath.equals(rootPath);
		if (!root) {
			items.add("back");
			paths.add(f.getParent());
			mOkButton.setEnabled(true);
		} else {
			mOkButton.setEnabled(false);
		}

		// String exs = Environment.getExternalStorageDirectory()
		// .getAbsolutePath();
		if (files != null) {
			for (int i = 0; i < files.length; i++) {
				File file = files[i];
				if (file.isDirectory()) {
					// if (root && !file.getPath().startsWith(exs))
					// continue;
					items.add(file.getName());
					paths.add(file.getPath());
				}
			}
		}
		
		PathSelectAdapter ad=new PathSelectAdapter(this, items, paths);
		
		
		lv.setAdapter(ad);
		lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
					//BaseApplication.ts(""+position);
					curPath = paths.get(position);
					getFileDir(paths.get(position));
				}
			});
		ad.notifyDataSetChanged();
		
		//znzsetListAdapter(new PathSelectAdapter(this, items, paths));
	}
	
	public void click(View button) {
		if (!button.isEnabled())
			return;
		switch (button.getId()) {
			case R.id.pathselectButton:
				PreferenceUtils.setPrefString(this,CL.APPDIRKEY,curPath);
				Intent intent18 = new Intent(this, MainActivity.class);
				startActivity(intent18);
				finish();
//			

				
				break;
			case R.id.pathselectButton2:
				finish();
				break;
		}
	}


	protected void onListItemClick(ListView lv, View v, int position, long id) {
		curPath = paths.get(position);
		getFileDir(paths.get(position));
		BaseApplication.ts("click");
	}

	public class PathSelectAdapter extends BaseAdapter {
		private LayoutInflater mInflater;
		private List<String> items;
		private List<String> paths;
		private Bitmap backIcon;
		private Bitmap dirIcon;
		private Bitmap fileIcon;
		
		
		public PathSelectAdapter(Context context, List<String> itemsIn,
								 List<String> pathsIn) {
			
			mInflater = LayoutInflater.from(context);
			items = itemsIn;
			paths = pathsIn;
		}
		
		
public void setItems(List<String> it){
	this.items=it;
}
		public void setPaths(List<String> it){
			this.paths=it;
		}
		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder holder;
			if (convertView == null) {
				convertView = mInflater.inflate(R.layout.pathselectitem, null);
				holder = new ViewHolder();
				holder.text = (TextView) convertView.findViewById(R.id.pathselectitemTextView1);
				holder.text2 = (TextView) convertView.findViewById(R.id.pathselectitemTextView2);
				//holder.icon= (ImageView) convertView.findViewById(R.id.icon);
				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}
			File f = new File(paths.get(position).toString());
			if (items.get(position).toString().equals("back")) {
				holder.text.setText("back");
				holder.text2.setText(" ");
				//holder.icon.setImageBitmap(backIcon);
			} else {
				holder.text.setText(f.getName());
				if(f.isFile()){
					//holder.icon.setImageBitmap(fileIcon);
					holder.text2.setText("[文件]");
				}
				else
				{
					holder.text2.setText("[文件夹]");
					//holder.icon.setImageBitmap(dirIcon);
				}
			}
			return convertView;
		}

		private class ViewHolder {
			TextView text;
			TextView text2;
			//ImageView icon;
		}

		public long getItemId(int position) {
			return position;
		}

		public Object getItem(int position) {
			return items.get(position);
		}

		public int getCount() {
			return items.size();
		}
	}

}
