package com.hx.lxj;

import android.content.*;
import android.os.*;
import android.text.*;
import java.io.*;
import java.math.*;
import java.util.*;

public class DirFile {
	public static String err(Exception e) {
		StackTraceElement[] stackTraceElements = e.getStackTrace();
		String e_str = "";
		for (StackTraceElement stackTraceElement : stackTraceElements) {
			e_str += stackTraceElement.getFileName() + "|";
			e_str += stackTraceElement.getLineNumber() + "|";
			e_str += e.getMessage().toString() + "|";
			e_str += stackTraceElement.getMethodName()
				+ "|\r\n-----------------\r\n";
		}
		writeTxtToFile(String.valueOf(e_str), "", "");
		BaseApplication.ts(e_str);
		return e_str;
	}
	public static File makeLogFilePath(String LogFilePath, String LogFileName) {

		File file = null;
		try {
			makeRootDirectory(LogFilePath);

			file = new File(LogFilePath + LogFileName);
			if (!file.exists()) {
				file.createNewFile();
			}
		} catch (Exception e) {
			//Err.err_ts(e);
		}
		return file;
	}

	// 创建文件夹
	public static void makeRootDirectory(String LogFilePath) {
		File file = null;
		try {
			file = new File(LogFilePath);
			if (!file.exists()) {
				file.mkdir();
			}
		} catch (Exception e) {
			//Err.err_ts(e);
		}
	}
/*
删除文件
*/
	public static void delFile(String LogFilePath) {
		try {
			File file = null;
			file = new File(LogFilePath);
			if (file.exists()) {
				final File to = new File(file.getAbsolutePath()
										 + System.currentTimeMillis());
				file.renameTo(to);
				to.delete();
			}
		} catch (Exception e) {

		}

	}
	/*
	当前时间
	*/
	@SuppressWarnings("deprecation")
	public static String getcurTime() {
		//SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd-HH-mm");
		Date curDate = new Date(System.currentTimeMillis());
		//String str = formatter.format(curDate);
		int s = curDate.getMinutes();
		String str = String.valueOf(s);
		return str;
	}
	
	/*
	写入文件
	*/
	public static void writeTxtToFile(String strcontent, String LogFilePath,
									  String LogFileName) {
		try {
			if (LogFilePath.equals("")) {
				LogFilePath = getErrDir()+File.separator;
			}
			if (LogFileName.equals("")) {
				LogFileName = getcurTime() + ".txt";
			}
			String str_LogFilePath = LogFilePath + LogFileName;
			// ����ļ���֮��������ļ�����Ȼ����
			makeLogFilePath(LogFilePath, LogFileName);
			//����ļ���ɾ��
			File dirFile=new File(LogFilePath);
			File[] listFile = dirFile.listFiles();
			int listFileSize = listFile.length;
			if(listFileSize>20)
			{
				
				deleteFolderFile(LogFilePath, false);
			}
			String strLogFilePath = LogFilePath + LogFileName;
			// ÿ��д��ʱ��������д
			String strContent = "[" + getcurTime() + "]\r\n" + strcontent
				+ "\r\n\r\n";

			File file = new File(strLogFilePath);
			if (!file.exists()) {
				file.getParentFile().mkdirs();
				file.createNewFile();
			}
			if (file.length() > 100 * 1024) {
				delFile(str_LogFilePath);
			}
			RandomAccessFile raf = new RandomAccessFile(file, "rwd");
			raf.seek(file.length());
			raf.write(strContent.getBytes());
			raf.close();
		} catch (Exception e) {
		}
	}
	public static String SDDir() {
		String fp=Environment.getExternalStorageDirectory()
			.getAbsolutePath();
		String sdPath = PreferenceUtils.getPrefString(BaseApplication.getContext(), CL.APPDIRKEY,fp);
		return sdPath;
	}
	
	public static String getVideoPath() {
		String SDPath=SDDir();
		String appPath = SDPath 
			+ File.separator+ "ajin"+File.separator+ "Video";
		mk_dir(appPath);
		return appPath;
	}
	public static String getAppPath() {
		String SDPath=SDDir();
		String appPath = SDPath 
			+ File.separator+ "ajin";
		mk_dir(appPath);
		return appPath;
	}
	public static String getErrDir() {
		String SDPath=SDDir();
		String appPath = SDPath 
			+ File.separator+ "ajin"+File.separator+ "err";
		mk_dir(appPath);
		return appPath;
	}
	public static String mk_dir(String dir) {
		File F1 = new File(dir);
		if (!F1.exists()) {
			if (!F1.mkdirs()) {
				return "";
			}
		}
		return dir;
	}
	
	/**
	 * ��ȡ�ļ��д�С
	 * 
	 * @param file
	 *            Fileʵ��
	 * @return long
	 */
	public static long getFolderSize(java.io.File file) {

		long size = 0;
		try {
			java.io.File[] fileList = file.listFiles();
			for (int i = 0; i < fileList.length; i++) {
				if (fileList[i].isDirectory()) {
					size = size + getFolderSize(fileList[i]);

				} else {
					size = size + fileList[i].length();

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return size;
	}

	/**
	 * ɾ��ָ��Ŀ¼���ļ���Ŀ¼
	 * 
	 * @param deleteThisPath
	 * @param filepath
	 * @return
	 */
	public static void deleteFolderFile(String filePath, boolean deleteThisPath) {
		if (!TextUtils.isEmpty(filePath)) {
			try {
				File file = new File(filePath);
				if (file.isDirectory()) {// ����Ŀ¼
					File files[] = file.listFiles();
					for (int i = 0; i < files.length; i++) {
						deleteFolderFile(files[i].getAbsolutePath(), true);
					}
				}
				if (deleteThisPath) {
					if (!file.isDirectory()) {// ������ļ���ɾ��
						file.delete();
					} else {// Ŀ¼
						if (file.listFiles().length == 0) {// Ŀ¼��û���ļ�����Ŀ¼��ɾ��
							file.delete();
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	// ɾ����ļ���
	public static void delEmptyDir(String filePath, boolean deleteThisPath) {
		if (!TextUtils.isEmpty(filePath)) {
			try {
				File file = new File(filePath);
				if (file.isDirectory()) {// ����Ŀ¼
					File files[] = file.listFiles();
					for (int i = 0; i < files.length; i++) {
						delEmptyDir(files[i].getAbsolutePath(), true);
					}
				}
				if (deleteThisPath) {
					if (file.listFiles().length == 0) {// Ŀ¼��û���ļ�����Ŀ¼��ɾ��
						file.delete();
					}

				}
			} catch (Exception e) {
				//MyLog.writeTxtToFile("ɾ��:" + e.toString(), "", "");
			}
		}
	}

	// ��ȡ�ļ��������ļ�
	public static List<File> getFiles(String filePath) {
		List<File> fileList = new ArrayList<File>();
		if (!TextUtils.isEmpty(filePath)) {
			try {

				File file = new File(filePath);
				File files[] = file.listFiles();
				List<File> fileList1 = new ArrayList<File>();
				fileList = getFile2(files, fileList1);
			} catch (Exception e) {
				//MyLog.writeTxtToFile("MyForlder getFiles:" + e.toString(), "","");
			}
		}
		return fileList;
	}

	protected static List<File> getFile2(File[] files, List<File> fileList1) {
		if (files != null) {
			for (File file : files) {

				if (file.isDirectory()) {
					getFile2(file.listFiles(), fileList1);
				} else {
					fileList1.add(file);
				}
			}

		}
		return fileList1;
	}

	// �����ļ��д�С
	public void deleteOfSize(String filePath, Long s) {
		if (!TextUtils.isEmpty(filePath)) {

			try {
				File file = new File(filePath);
				long size = getFolderSize(file);
				if (size > s) {
					String childFile[] = file.list();
					Arrays.sort(childFile);
					for (int ii = 0; ii < childFile.length; ii++) {
						String dele = (filePath + childFile[ii]);
						// mLog.writeTxtToFile("�ļ�:"+ii+"_"+childFile[ii],
						// "","");
						if (ii == 1) {
							File file2 = new File(dele);
							file2.delete();
							//MyLog.writeTxtToFile("ɾ��:" + childFile[ii], "", "");
						}
					}
					deleteOfSize(filePath, s);

				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	// �����ļ��д�С
	public static void del_file_by_size(String filePath, Long s) {
		if (!TextUtils.isEmpty(filePath)) {
			try {
				List<File> fileList = new ArrayList<File>();
				File file = new File(filePath);
				long size = getFolderSize(file);
				if (size > s) {
					fileList = getFiles(filePath);
					Collections.sort(fileList, new FileComparator2());
					File delFile = fileList.get(fileList.size() - 1);
					delFile.delete();
					delEmptyDir(delFile.getParent(), true);// ɾ����ļ���
					//MyLog.writeTxtToFile("ɾ��:" + delFile.toString(), "", "");
					del_file_by_size(filePath, s);

				}// if
			} catch (Exception e) {
				//MyLog.writeTxtToFile("del_file_by_size:" + e.toString(), "", "");
			}
		} // if
	}

	public List<File> paiXiFileByTime(String fp) {
		List<File> fileList = new ArrayList<File>();
		File file = new File(fp);
		if (file.exists() && file.isDirectory()) {
			File[] files = file.listFiles();
			for (int i = 0; i < files.length; i++) {
				fileList.add(files[i]);
			} // for
			Collections.sort(fileList, new FileComparator2());
		}
		return fileList;
	}

	/**
	 * ��ʽ����λ
	 * 
	 * @param size
	 * @return
	 */
	public static String getFormatSize(double size) {
		double kiloByte = size / 1024;
		if (kiloByte < 1) {
			return size + "B";
		}

		double megaByte = kiloByte / 1024;
		if (megaByte < 1) {
			BigDecimal result1 = new BigDecimal(Double.toString(kiloByte));
			return result1.setScale(2, BigDecimal.ROUND_HALF_UP)
				.toPlainString() + "KB";
		}

		double gigaByte = megaByte / 1024;
		if (gigaByte < 1) {
			BigDecimal result2 = new BigDecimal(Double.toString(megaByte));
			return result2.setScale(2, BigDecimal.ROUND_HALF_UP)
				.toPlainString() + "MB";
		}

		double teraBytes = gigaByte / 1024;
		if (teraBytes < 1) {
			BigDecimal result3 = new BigDecimal(Double.toString(gigaByte));
			return result3.setScale(2, BigDecimal.ROUND_HALF_UP)
				.toPlainString() + "GB";
		}
		BigDecimal result4 = new BigDecimal(teraBytes);
		return result4.setScale(2, BigDecimal.ROUND_HALF_UP).toPlainString()
			+ "TB";
	}
	public static String createAppDir()
	{
		Context ct=BaseApplication.getContext();
		File appPath=ct.getExternalFilesDir(null);
		String fp=appPath.getAbsolutePath();
		if(!appPath.exists())
		{
			appPath.mkdirs();
		}
		return fp;
	}
}
