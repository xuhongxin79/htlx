package com.hx.lxj;

import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.List;



import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.SurfaceHolder.Callback;
import android.view.WindowManager.LayoutParams;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class Player extends Activity {
	// private Button mVideoStartBtn;
	// private Drawable iconStart;
	// private Drawable iconStop;
	TextView tv;
	private SurfaceView mSurfaceview;
	private SurfaceHolder mSurfaceHolder;
	public String MyExSDPath = "";
	public String appDir = "";
	MediaPlayer mPlayer;
	public String path;
	private String pathrt;
	public int psi = 0;
	public int sds = 1;
	boolean isLand = false;
	LinearLayout relLay;

	// View R1 ;
	@SuppressWarnings("deprecation")
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		try {

			this.requestWindowFeature(Window.FEATURE_NO_TITLE);
			// this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
			getWindow().setFormat(PixelFormat.TRANSLUCENT);
			// setContentView(R.layout.map_video);
			// LayoutInflater inflater =
			// LayoutInflater.from(getApplicationContext());
			// this.R1 = inflater.inflate(R.id.rl, null);

			this.MyExSDPath = DirFile.getAppPath();
			appDir = DirFile.getVideoPath();
			// iconStart =
			// getResources().getDrawable(R.drawable.arc_hf_btn_video_start);
			// iconStop =
			// getResources().getDrawable(R.drawable.arc_hf_btn_video_stop);

			// mVideoStartBtn = (Button) findViewById(R.id.arc_hf_video_start);
			// mSurfaceview = (SurfaceView)
			// this.findViewById(R.id.arc_hf_video_view);
			mSurfaceview = new SurfaceView(this);
			DisplayMetrics dm = getResources().getDisplayMetrics();
			float screenWidth = dm.widthPixels;
			// float screenHeight = dm.heightPixels;
			float bl = 9f / 16f;
			//MyLog.writeTxtToFile("比例" + String.valueOf(bl), "", "");
			float mKuan = screenWidth;
			int h = (int) (mKuan * bl);

			LayoutParams params_sur = new LayoutParams();
			params_sur.width = (int) mKuan;
			params_sur.height = h + 60;
			params_sur.alpha = 255;
			mSurfaceview.setLayoutParams(params_sur);

			relLay = new LinearLayout(this);
			LayoutParams mLayoutParams = new WindowManager.LayoutParams();
			mLayoutParams.type = WindowManager.LayoutParams.TYPE_PHONE;
			mLayoutParams.format = 1;
			mLayoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
				| WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
			mLayoutParams.gravity = Gravity.CENTER_HORIZONTAL | Gravity.CENTER;
			// mLayoutParams.gravity =Gravity.LEFT|Gravity.TOP;
			mLayoutParams.x = 0;
			mLayoutParams.y = 0;
			// mLayoutParams.width = screenWidth;
			// mLayoutParams.height = screenHeight;
			mLayoutParams.width = (int) mKuan;
			mLayoutParams.height = h;
			relLay.setLayoutParams(mLayoutParams);

			relLay.addView(mSurfaceview);
			tv = new TextView(this);
			tv.setHeight(30);
			tv.setMaxWidth((int) screenWidth);
			tv.setTextColor(Color.rgb(255, 255, 255));
			relLay.addView(tv);

			setContentView(relLay);
			getWindow()
				.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

			Intent intent = getIntent();
			path = intent.getStringExtra("f");
			psi = Integer.valueOf(intent.getStringExtra("ps"));

			//MyLog.writeTxtToFile("play" + psi, "", "");
			// ��Ԥ����ͼ
			SurfaceHolder holder = mSurfaceview.getHolder();
			holder.addCallback(new Callback() {

					@Override
					public void surfaceDestroyed(SurfaceHolder holder) {

					}

					@Override
					public void surfaceCreated(SurfaceHolder holder) {
						mSurfaceHolder = holder;
						play(getFile());
					}

					@Override
					public void surfaceChanged(SurfaceHolder holder, int format,
											   int width, int height) {
						mSurfaceHolder = holder;
					}

				});
			holder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
		} catch (NumberFormatException e) {
			//MyLog.writeTxtToFile("play onCreate" + e.toString(), "", "");
		}

	}

	public void play(final String fileName) {
		mPlayer = new MediaPlayer();
		mPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
		mPlayer.setDisplay(mSurfaceHolder); // ����һ��SurfaceView������
		// setVideoParams(mPlayer,isLand);
		mPlayer.setOnCompletionListener(new OnCompletionListener() {
				public void onCompletion(MediaPlayer arg0) {
					stop();
					psi--;
					//MyLog.writeTxtToFile("ps" + psi, "", "");
					play(getFile());
					// canvas.drawColor(Color.TRANSPARENT,
					// PorterDuff.Mode.CLEAR);
				}
			});
		try {
			mPlayer.setDataSource(fileName);
			// setVideoParamter(mPlayer,
			// getResources().getConfiguration().orientation ==
			// Configuration.ORIENTATION_LANDSCAPE);

			mPlayer.prepare();
			// mVideoStartBtn.setBackgroundDrawable(iconStart);
		} catch (IllegalStateException e) {

			//MyLog.writeTxtToFile("play play" + e.toString(), "", "");
		} catch (IOException e) {
			//MyLog.writeTxtToFile("play play" + e.toString(), "", "");
		}
		mPlayer.start();

	}

	public void stop() {
		if (mPlayer != null) {
			mPlayer.release();
			mPlayer = null;
		}
	}

	@SuppressLint("ShowToast")
	private String getFile() {
		tv.setText("psi" + psi);
		List<File> fileList = DirFile.getFiles(appDir);
		Collections.sort(fileList, new FileComparator2());
		int count = fileList.size();
		if (psi > count) {
			psi = 0;
		}
		if (psi < 0) {
			psi = count - 1;
		}
		File f = fileList.get(psi);
		pathrt = f.getPath();
		// MyLog.writeTxtToFile("���ţ�"+pathrt+","+psi+","+count, "", "");
		Toast.makeText(Player.this, "路径" + pathrt, Toast.LENGTH_LONG)
			.show();
		// File file = new File(path);
		// files = file.listFiles();
		// Arrays.sort(files);
		// int count = files.length;
		// if(psi>=count){
		// psi=0;
		// }
		// File f = files[psi];
		// pathrt = f.getPath();
		return pathrt;
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
			// ��ɺ�����
			setVideoParams(mPlayer, true);
		} else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
			// ���������
			setVideoParams(mPlayer, false);
		}
	}

	private void setVideoParams(MediaPlayer mPlayer2, boolean isLand) {
		// ��ȡsurfaceView�����ֵĲ���
		ViewGroup.LayoutParams rl_paramters = relLay.getLayoutParams();
		// ��ȡSurfaceView�Ĳ���
		ViewGroup.LayoutParams sv_paramters = mSurfaceview.getLayoutParams();
		// ���ÿ�߱�Ϊ16/9
		float screen_widthPixels = getResources().getDisplayMetrics().widthPixels;
		float screen_heightPixels = getResources().getDisplayMetrics().widthPixels * 9f / 16f;
		// ȡ��ȫ��
		getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
		if (isLand) {
			screen_heightPixels = getResources().getDisplayMetrics().heightPixels;
			// ����ȫ��
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
		}
		rl_paramters.width = (int) screen_widthPixels;
		rl_paramters.height = (int) screen_heightPixels;

		// ��ȡMediaPlayer�Ŀ��
		int videoWidth = mPlayer.getVideoWidth();
		int videoHeight = mPlayer.getVideoHeight();

		float video_por = videoWidth / videoHeight;
		float screen_por = screen_widthPixels / screen_heightPixels;
		// 16:9 16:12
		if (screen_por > video_por) {
			sv_paramters.height = (int) screen_heightPixels;
			sv_paramters.width = (int) (screen_heightPixels * screen_por);
		} else {
			// 16:9 19:9
			sv_paramters.width = (int) screen_widthPixels;
			sv_paramters.height = (int) (screen_widthPixels / screen_por);
		}
		relLay.setLayoutParams(rl_paramters);
		mSurfaceview.setLayoutParams(sv_paramters);

	}

	@Override
	public boolean onKeyUp(int keyCode, KeyEvent event) {

		switch (keyCode) {
			case KeyEvent.KEYCODE_MEDIA_PREVIOUS:

				break;
			case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:

				break;
			case KeyEvent.KEYCODE_HEADSETHOOK:
				myplay();
				break;

			case KeyEvent.KEYCODE_MEDIA_NEXT:
				stop();
				psi--;
				play(getFile());

				break;
			case KeyEvent.KEYCODE_BACK:
				getWindow().clearFlags(
					WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
				stop();
				System.exit(0);
				break;

		}
		return false;

	}

	private void myplay() {
		if (mPlayer != null) {
			mPlayer.release();
			mPlayer = null;
			// mVideoStartBtn.setBackgroundDrawable(iconStop);
		} else {
			play(getFile());
			// mVideoStartBtn.setBackgroundDrawable(iconStart);
		}

	}

}
