package com.hx.lxj;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity implements RadioGroup.OnCheckedChangeListener 
{
	Context ct;
private TextView tv;
	private RadioGroup r1;
	private RadioButton r11;
	private RadioButton r12;
	
	private RadioGroup r2;
	private RadioButton r21;
	private RadioButton r22;
	private RadioButton r23;
	private RadioButton r24;
	
	private RadioGroup r3;
	private RadioButton r31;
	private RadioButton r32;
	private RadioButton r33;
	private RadioButton r34;
	
	private RadioGroup r4;
	private RadioButton r41;
	private RadioButton r42;
	private RadioButton r43;
	private RadioButton r44;
	
	private RadioGroup r5;
	private RadioButton r51;
	private RadioButton r52;
	private RadioButton r53;
	private RadioButton r54;
	
	private EditText et1;
	private EditText et2;
	private EditText et3;
	private EditText et4;
	private EditText et5;
	private String kl2="";
	private String kl0="";
	private String mac="";
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		DirFile.createAppDir();
		
		
		//appdir=PreferenceUtils.getPrefString(ct,"appdir","");
		/*if(appdir.equals("")){
			Intent in=new Intent(this,SelectDir.class);
			startActivity(in);
			this.finish();
		}*/
		ct=this;
		
		tv=(TextView)findViewById(R.id.appdir);
		String fp=PreferenceUtils.getPrefString(ct,CL.APPDIRKEY,"请选择保存的路径");
		tv.setText("路径:"+fp);
		r1= (RadioGroup) this.findViewById(R.id.r1);
		r1.setOnCheckedChangeListener(this);
		r11= (RadioButton) this.findViewById(R.id.r11);
		r12= (RadioButton) this.findViewById(R.id.r12);
		
		r2= (RadioGroup) this.findViewById(R.id.r2);
		r2.setOnCheckedChangeListener(this);
		r21= (RadioButton) this.findViewById(R.id.r21);
		r22= (RadioButton) this.findViewById(R.id.r22);
		r23= (RadioButton) this.findViewById(R.id.r23);
		r24= (RadioButton) this.findViewById(R.id.r24);
		
		
		
		r3= (RadioGroup) this.findViewById(R.id.r3);
		r3.setOnCheckedChangeListener(this);
		r31= (RadioButton) this.findViewById(R.id.r31);
		r32= (RadioButton) this.findViewById(R.id.r32);
		r33= (RadioButton) this.findViewById(R.id.r33);
		r34= (RadioButton) this.findViewById(R.id.r34);
		
		r4= (RadioGroup) this.findViewById(R.id.r4);
		r4.setOnCheckedChangeListener(this);
		r41= (RadioButton) this.findViewById(R.id.r41);
		r42= (RadioButton) this.findViewById(R.id.r42);
		r43= (RadioButton) this.findViewById(R.id.r43);
		r44= (RadioButton) this.findViewById(R.id.r44);
		
		r5= (RadioGroup) this.findViewById(R.id.r5);
		r5.setOnCheckedChangeListener(this);
		r51= (RadioButton) this.findViewById(R.id.r51);
		r52= (RadioButton) this.findViewById(R.id.r52);
		r53= (RadioButton) this.findViewById(R.id.r53);
		r54= (RadioButton) this.findViewById(R.id.r54);
		et1=(EditText)this.findViewById(R.id.e1);
		et2=(EditText)this.findViewById(R.id.e2);
		et3=(EditText)this.findViewById(R.id.e3);
		et4=(EditText)this.findViewById(R.id.mainEditText1);
		mac=BaseApplication.getNewMac();
		mac=mac.replace(":","");
		et4.setText(mac);
		et5=(EditText)this.findViewById(R.id.mainEditText2);
		kl0=PreferenceUtils.getPrefString(ct,CL.KLKEY2,"");
		et5.setText(kl0);
		setPre();
		Intent in=this.getIntent();
		String s=in.getStringExtra("action");
		if(s!=null&&s.equals("stop")){
			stopAlarm();
		}
    }
	private void setPre(){
		int jt=PreferenceUtils.getPrefInt(ct,"jt",1);
		if(jt==2){
		r11.setChecked(true);
		r12.setChecked(false);
		}else{
			r12.setChecked(true);
			r11.setChecked(false);
		}
		int pmdx=PreferenceUtils.getPrefInt(ct,"pinmodaxiao",500);
		if(pmdx==1){
			r21.setChecked(true);
		}else if(pmdx==200){
			r22.setChecked(true);
		}else if(pmdx==500){
			r23.setChecked(true);
		}else if(pmdx==600){
			r24.setChecked(true);
		}
		//相机角度
		int xjjd=PreferenceUtils.getPrefInt(ct,"xjjd",0);
		if(xjjd==0){
			r31.setChecked(true);
		}else if(xjjd==90){
			r32.setChecked(true);
		}else if(xjjd==180){
			r33.setChecked(true);
		}else if(xjjd==270){
			r34.setChecked(true);
		}
		//媒体角度
		int mtjd=PreferenceUtils.getPrefInt(ct,"mtjd",90);
		
		if(mtjd==0){
			r41.setChecked(true);
		}else if(mtjd==90){
			r42.setChecked(true);
		}else if(mtjd==180){
			r43.setChecked(true);
		}else if(mtjd==270){
			r44.setChecked(true);
		}
		
		//视频大小
		int spdx=PreferenceUtils.getPrefInt(ct,"spdx",2);
		if(spdx==0){
			r51.setChecked(true);
		}else if(spdx==1){
			r52.setChecked(true);
		}else if(spdx==2){
			r53.setChecked(true);
		}else if(spdx==3){
			r54.setChecked(true);
		}
		int ms=PreferenceUtils.getPrefInt(ct,"ms",60);
		et1.setText(ms+"");
		
		int nc=PreferenceUtils.getPrefInt(ct,"nc",2000);
		et3.setText(nc+"");
		
		String wjm=PreferenceUtils.getPrefString(ct,"wjm","");
		et2.setText(wjm);
	}
	public void click(View view) {
      int id=view.getId();
	   switch(id){
		   case R.id.set:
		   
			   int ms=Integer.parseInt(et1.getText().toString());
			   PreferenceUtils.setPrefInt(ct,"ms",ms);
			 
			   
		   
			   String wjm=et2.getText().toString();
			   PreferenceUtils.setPrefString(ct,"wjm",wjm);
			   
			   
		   
			   int nc=Integer.parseInt(et3.getText().toString());
			   PreferenceUtils.setPrefInt(ct,"nc",nc);
			   
			   String kl1=et5.getText().toString();
			   String zcm=et4.getText().toString();
			   
			   kl2=kl(mac);
			   
			   if(kl1.equals("hx")){
				   et2.setText(kl2);
			   }else{
				   PreferenceUtils.setPrefString(ct,CL.ZCMKEY,zcm);
				   PreferenceUtils.setPrefString(ct,CL.KLKEY1,kl2);
			   PreferenceUtils.setPrefString(ct,CL.KLKEY2,kl1);
			   }
			   ts("设置保存成功");
			   
			   break;
			   case R.id.lx:
			PreferenceUtils.setPrefInt(ct,"isLx",1);
				
			   startAlarm();
			   //Intent intent3 = new Intent(MainActivity.this, Server.class);
			   //startService(intent3);
				   break;
		 case R.id.appdir:
			   
			  Intent intent3 = new Intent(MainActivity.this, SelectDir.class);
			  startActivity(intent3);
			 finish();
			break;
			case R.id.stoplx:
				//ts("停止");
			   stopAlarm();
			// Intent intent2=new Intent(MainActivity.this, Server.class);
			 //  stopService(intent2);
				break;
			//录像列表
			case R.id.t3:
			   String videoPath = DirFile.getVideoPath();
			   Intent intent = new Intent();
			   intent.putExtra("path", videoPath);
			   intent.setClass(MainActivity.this, FileList.class);
			   startActivity(intent);
				break;
			case R.id.t4:
			   Intent it=new Intent(MainActivity.this, WebView1.class);
			   startActivity(it);
			   break;
	   }
		    
    }
	
	@Override
	public void onCheckedChanged(RadioGroup group, int checkedId) {
		//得到用户选中的 RadioButton 对象
		//RadioButton radioButton_checked= (RadioButton) group.findViewById(checkedId);
		//String t1=radioButton_checked.getText().toString();
	
		switch (checkedId){
			case R.id.r11:
				//前镜头
				
				PreferenceUtils.setPrefInt(ct,"jt",2);
				//ts("设置为前镜头");
				break;
			case R.id.r12:
				//后镜头
				
				PreferenceUtils.setPrefInt(ct,"jt",1);
				//ts("设置为后镜头");
				break;
			case R.id.r21:
			//pinmodaxiao
				PreferenceUtils.setPrefInt(ct,"pinmodaxiao",1);
				//ts("预览大小设置保存成功");
				break;
			
			case R.id.r22:
				//pinmodaxiao
				PreferenceUtils.setPrefInt(ct,"pinmodaxiao",200);
				//ts("预览大小设置保存成功");
				break;
			
			case R.id.r23:
				//pinmodaxiao
				PreferenceUtils.setPrefInt(ct,"pinmodaxiao",500);
				//ts("预览大小设置保存成功");
				break;
			
			case R.id.r24:
				//pinmodaxiao
				PreferenceUtils.setPrefInt(ct,"pinmodaxiao",600);
				//ts("预览大小设置保存成功");
				break;
			//相机角度
			case R.id.r31:
				//pinmodaxiao
				PreferenceUtils.setPrefInt(ct,"xjjd",0);
				//ts("相机角度设置保存成功");
				break;

			case R.id.r32:
				//pinmodaxiao
				PreferenceUtils.setPrefInt(ct,"xjjd",90);
				//ts("相机角度设置保存成功");
				break;

			case R.id.r33:
				//pinmodaxiao
				PreferenceUtils.setPrefInt(ct,"xjjd",180);
				//ts("相机角度设置保存成功");
				break;

			case R.id.r34:
				//pinmodaxiao
				PreferenceUtils.setPrefInt(ct,"xjjd",270);
				//ts("相机角度设置保存成功");
				break;
				//媒体角度
			case R.id.r41:
				//pinmodaxiao
				PreferenceUtils.setPrefInt(ct,"mtjd",0);
				//ts("媒体角度设置保存成功");
				break;

			case R.id.r42:
				//pinmodaxiao
				PreferenceUtils.setPrefInt(ct,"mtjd",90);
				//ts("媒体角度设置保存成功");
				break;

			case R.id.r43:
				//pinmodaxiao
				PreferenceUtils.setPrefInt(ct,"mtjd",180);
				//ts("媒体角度设置保存成功");
				break;

			case R.id.r44:
				//pinmodaxiao
				PreferenceUtils.setPrefInt(ct,"mtjd",270);
				//ts("媒体角度设置保存成功");
				break;
				
				//视频大小
			case R.id.r51:
				//pinmodaxiao
				PreferenceUtils.setPrefInt(ct,"spdx",0);
				//ts("视频质量设置保存成功");
				break;

			case R.id.r52:
				//pinmodaxiao
				PreferenceUtils.setPrefInt(ct,"spdx",1);
				//ts("视频质量设置保存成功");
				break;

			case R.id.r53:
				//pinmodaxiao
				PreferenceUtils.setPrefInt(ct,"spdx",2);
				//ts("视频质量设置保存成功");
				break;

			case R.id.r54:
				//pinmodaxiao
				PreferenceUtils.setPrefInt(ct,"spdx",3);
				//ts("视频质量设置保存成功");
				break;
			
		}
		
	}
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {  
		switch (keyCode) 
		{  
			case KeyEvent.KEYCODE_VOLUME_UP:  
				//BaseApplication.ts("up");
				int islx3=PreferenceUtils.getPrefInt(ct,"isLx",0);
				if(islx3==0){
					PreferenceUtils.setPrefInt(ct,"isLx",1);
					startAlarm();
				}else if(islx3==1){
					PreferenceUtils.setPrefInt(ct,"isLx",0);
					//Server.stop();
					islx3=0;
					stopAlarm();
				}
				return true;  
			case KeyEvent.KEYCODE_VOLUME_DOWN:  
				
				int islx=PreferenceUtils.getPrefInt(ct,"isLx",0);
				if(islx==0){
				PreferenceUtils.setPrefInt(ct,"isLx",1);
				startAlarm();
				}else if(islx==1){
					PreferenceUtils.setPrefInt(ct,"isLx",0);
					//Server.stop();
					islx=0;
					stopAlarm();
				}
				
				return true;  
			case KeyEvent.KEYCODE_BACK :
				finish();
				break;
			default:  
				break;  
		}  
		return false;  
	} 
	
	public void ts(String str) {
		Toast.makeText(ct, str, Toast.LENGTH_LONG).show();
	}
	private void startAlarm() {
		String kl3=kl(mac);
		//ts(kl3);
		if(kl3.equals(kl0)){
		// stopAlarm();
		// star service
		Intent intent2 = new Intent(MainActivity.this, Server.class);
		startService(intent2);
		// start alarm
		int id = 1;
	String LILY_TEST_INTENT = "com.hx.hxtestintent2";
		AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
		Intent intent = new Intent(LILY_TEST_INTENT);
		intent.setData(Uri.parse("content://calendar/calendar_alerts/1"));
		intent.setClass(this, Receiver.class);
		intent.putExtra("ID", id);
		long atTimeInMillis = System.currentTimeMillis();
		intent.putExtra("time", atTimeInMillis);
		// intent.putExtra(LABEL, label);
		// intent.putExtra(TIME, atTimeInMillis);
		PendingIntent sender = PendingIntent.getBroadcast(this, 0, intent,
														  PendingIntent.FLAG_CANCEL_CURRENT);
		// am.set(AlarmManager.RTC_WAKEUP, atTimeInMillis, sender);
		am.setRepeating(AlarmManager.ELAPSED_REALTIME,
						SystemClock.elapsedRealtime(), 15 * 1000, sender);
		
		}else{
			BaseApplication.ts("请向微信wx2310150678\n索取口令");
		}
	}
	public void stopAlarm() {

		int id = 2;

		Intent intent2 = new Intent(MainActivity.this, Server.class);
		stopService(intent2);
		AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
		String LILY_TEST_INTENT = "com.hx.hxtestintent2";
		Intent intent = new Intent(LILY_TEST_INTENT);
		intent.setClass(this, Receiver.class);
		intent.putExtra("ID", id);
		intent.setData(Uri.parse("content://calendar/calendar_alerts/1"));
		// id = 2;
		// Log.i("lily","id = 2");
		// intent.putExtra(ID, id);
		PendingIntent sender = PendingIntent.getBroadcast(this, 0, intent,
														  PendingIntent.FLAG_NO_CREATE);
		if (sender != null) {
			am.cancel(sender);
			Toast.makeText(MainActivity.this, "停止", Toast.LENGTH_SHORT).show();
		}
		ActivityManager activityMgr = (ActivityManager) this
			.getSystemService(ACTIVITY_SERVICE);
		activityMgr.killBackgroundProcesses(getPackageName());
		android.os.Process.killProcess(android.os.Process.myPid());
		// ActivityManager manager =
		// (ActivityManager)getSystemService(Context.ACTIVITY_SERVICE);
		// manager.killBackgroundProcesses("com.hongxin.wcf");
	}
	//口令返回
	public String kl(String mac){
		String mac1=mac.replace(":","");
		mac1=mac1.toLowerCase();
		mac1=mac1.replace("1","Y")
		.replace("2","E")
		.replace("3","S")
		.replace("4","S")
		.replace("5","W")
		.replace("6","L")
		.replace("7","Q")
		.replace("8","B")
		.replace("9","J")
		.replace("0","L")
		.replace("a","2")
		.replace("b","2")
		.replace("c","1")
		.replace("e","1")
		.replace("d","2")
		.replace("f","2")
		.replace("g","2")
		.replace("h","4")
		.replace("i","4")
		.replace("j","4")
		.replace("k","4")
		.replace("l","3")
		.replace("m","5")
		.replace("n","4")
		.replace("o","5")
		.replace("p","6")
		.replace("r","6")
		.replace("s","5")
		.replace("t","6")
		.replace("u","8")
		.replace("v","7")
		.replace("w","8")
		.replace("x","8")
		.replace("y","8")
		.replace("z","7");
		mac1= new StringBuffer(mac1).reverse().toString();
		
		return mac1;
	}
}
