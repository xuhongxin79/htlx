package com.hx.lxj;

import android.annotation.*;
import android.content.*;
import android.graphics.*;
import android.hardware.*;
import android.hardware.Camera.*;
import android.media.*;
import android.os.*;
import android.view.*;
import java.io.*;
import java.text.*;
import java.util.*;

import android.hardware.Camera;

public class ThreadC extends Thread {
	private MediaRecorder mediarecorder;//
	private SurfaceHolder surfaceHolder;
	private SurfaceView surfaceview;//
	static Camera mCamera;
	private long recordTime;
	private Context context;
	private long startTime = Long.MIN_VALUE;
	private long endTime = Long.MIN_VALUE;
	private HashMap<String, String> map = new HashMap<String, String>();
	public boolean exit;
	public static final int MEDIA_TYPE_IMAGE = 1;
	public static final int MEDIA_TYPE_VIDEO = 2;
	static ThreadC thread;
	public long nc = 1;
	public int jt = 1;
	public int jd = 0;
	public int cjd = 0;
	public int ms = 15000;
	public static String wjm = "";
	public int int_kuan_p = 1280;
	public int int_height_p = 720;
	public static String app_dir = "";
	public static int sds = 0;
	public boolean isStop = true;
	public Handler handlerAP=null;
	public int islx1=0;

	public ThreadC(long recordTime, SurfaceView surfaceview,
	SurfaceHolder surfaceHolder,Handler handler, Context context) {
		this.recordTime = recordTime;
		this.surfaceview = surfaceview;
		this.surfaceHolder = surfaceHolder;
		this.context = context;
		this.handlerAP=handler;
		
		String str_wjm = PreferenceUtils.getPrefString(context,"wjm","");
		int str_jt = PreferenceUtils.getPrefInt(context,"jt",1);
		int str_jd = PreferenceUtils.getPrefInt(context,"xjjd",0);
		int str_cjd = PreferenceUtils.getPrefInt(context,"mtjd",90);
		int str_nc = PreferenceUtils.getPrefInt(context,"nc",2000);
		int str_sc = PreferenceUtils.getPrefInt(context,"ms",2000);
		int str_kuan_p = PreferenceUtils.getPrefInt(context,"spdx",1);
		
		if (!str_wjm.equals("")) {
			ThreadC.wjm = str_wjm;
		}
		if (str_jt>=0) {
			this.jt = str_jt;
		}
		if (str_jd>=0) {
			this.jd = str_jd;
		}
		if (str_cjd>=0) {
			this.cjd = str_cjd;
		}
		if (str_nc>=0) {
			this.nc = str_nc;
		}
		if (str_sc>=0) {
			this.ms = str_sc* 1000;// 秒数
		}
		if (str_kuan_p==0) {
			this.int_kuan_p = 521;
					  this.int_height_p=384;
		}else if(str_kuan_p==1){
		 this.int_kuan_p =800;
		this.int_height_p=480;
		}else if(str_kuan_p==3){
					  this.int_kuan_p =1920;
					  this.int_height_p=1080;
		}else{
					  this.int_kuan_p =1280;
					  this.int_height_p=720;
					  
		}
		

		new AutoFocusCallback() {
			public void onAutoFocus(boolean success, Camera camera) {
				if (success)// success��ʾ�Խ��ɹ�
				{
					// myCamera.setOneShotPreviewCallback(null);

				}
			}
		};
	}

	@Override
	public void run() {
		islx1=PreferenceUtils.getPrefInt(BaseApplication.getContext(),"isLx",0);
		while (isStop && islx1==1) {
			try {
				if (islx1 ==1 && isStop == true) {

					startRecord();
					Timer timer = new Timer();
					timer.schedule(new TimerThread(), recordTime);
					isStop = false;
				}else{
					break;
				}

			} catch (Exception e) {
			//DirFile.err(e);
				break;
			}
		}
	}

	/** * ��ȡ����ͷʵ����� * * @return */
	@SuppressWarnings("deprecation")
	public Camera getCameraInstance() {
		mCamera = null;
		try {
			//MyLog.writeTxtToFile("��ȡ����ͷʵ�����", "", "");
			if (jt == 1) {
				mCamera = Camera.open(Camera.CameraInfo.CAMERA_FACING_BACK);
			} else {
				mCamera = Camera.open(Camera.CameraInfo.CAMERA_FACING_FRONT);
			}

			mCamera.setDisplayOrientation(cjd);
			Camera.Parameters parameters = mCamera.getParameters();
			//List<Size> list = parameters.getSupportedPictureSizes();
			List<Size> list2 = parameters.getSupportedVideoSizes();
			int index = bestVideoSize(list2);
			int_kuan_p=list2.get(index).width;
			int_height_p=list2.get(index).height;
			parameters.setPreviewFrameRate(5); // ÿ��5֡
			parameters.setPictureFormat(PixelFormat.JPEG);// ������Ƭ������ʽ
			parameters.set("jpeg-quality", 99);// ��Ƭ���
			parameters
				.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
			// camera.autoFocus(myAutoFocusCallback);
			mCamera.cancelAutoFocus();// 2���Ҫʵ�������Զ��Խ�����һ��������
			//mCamera.setParameters(parameters);
			Camera.Parameters p =mCamera.getParameters();
			int progress1=PreferenceUtils.getPrefInt(BaseApplication.getContext(),"fsu",0);
			p.setZoom(progress1);
			mCamera.setParameters(p);
			mCamera.startPreview();
		} catch (Exception e) {
			DirFile.err(e);
		}
		return mCamera;
	}
	//
	public int bestVideoSize(List<Size> videoSizeList){
	
		Collections.sort(videoSizeList, new Comparator<Camera.Size>() {
	            @Override
	            public int compare(Camera.Size lhs, Camera.Size rhs) {
	                if (lhs.width > rhs.width) {
	                    return -1;
	                } else if (lhs.width == rhs.width) {
	                    return 0;
	                } else {
	                    return 1;
	                }
	            }
	        });
		for(int i=0;i<videoSizeList.size();i++){
			if(videoSizeList.get(i).width<=int_kuan_p){
				return i;
			}
		}
		return 0;
	}

	/** * ��ʼ¼�� */
	public void startRecord() {
		try {
			//float r1=int_kuan_p/int_height_p;
			//if(r1!=16/9){
			//int_height_p=int_kuan_p/16*9;
			//}
			mediarecorder = new MediaRecorder();// ����mediarecorder����
			mCamera = getCameraInstance(); // ����camera
			mCamera.unlock();

			mediarecorder.setCamera(mCamera); // ����¼����ƵԴΪCamera(���)
			mediarecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
			mediarecorder.setVideoSource(MediaRecorder.VideoSource.CAMERA); // ����¼���ļ��������ʽ���ֱ���֮�࣬���ȫ�������
			//
			// if(CamcorderProfile.hasProfile(CamcorderProfile.QUALITY_1080P)){
			// mediarecorder.setProfile(CamcorderProfile.get(CamcorderProfile.QUALITY_1080P));
			// }
			// else
			// if(CamcorderProfile.hasProfile(CamcorderProfile.QUALITY_720P)){
			// mediarecorder.setProfile(CamcorderProfile.get(CamcorderProfile.QUALITY_720P));
			// }
			// else if
			// (CamcorderProfile.hasProfile(CamcorderProfile.QUALITY_HIGH)){
			// mediarecorder.setProfile(CamcorderProfile.get(CamcorderProfile.QUALITY_HIGH));
			// }
			// mediarecorder.setOutputFile("/sdcard/sForm.3gp");

			// �����ļ�·��
			mediarecorder.setOutputFile(getOutputMediaFile(MEDIA_TYPE_VIDEO)
										.toString());
			mediarecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
			mediarecorder.setVideoSize(int_kuan_p, int_height_p);
			//mediarecorder.setVideoEncoder(MediaRecorder.VideoEncoder.MPEG_4_SP);
			mediarecorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
			mediarecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
			mediarecorder.setVideoFrameRate(30);
			mediarecorder.setVideoEncodingBitRate(20 * 1024 * 1024);
			mediarecorder.setPreviewDisplay(surfaceHolder.getSurface()); // ������Ƶ�ļ�����·��
			mediarecorder.setOrientationHint(jd);
			// ׼��¼��
			mediarecorder.prepare(); // ��ʼ¼��
			mediarecorder.start();

		} catch (IllegalStateException e) {
			DirFile.err(e);
		} catch (IOException e) {
			DirFile.err(e);
		}
	}

	public void releaseMediaRecorder() {
		if (mediarecorder != null) {
			// ���recorder����
			mediarecorder.reset();
			// �ͷ�recorder����
			mediarecorder.release();
			mediarecorder = null;
			// Ϊ����ʹ��������ͷ
			mCamera.lock();
			// MyLog.writeTxtToFile("�ͷųɹ�","","");
		}
	}

	/** * ֹͣ¼�� */
	public void stopRecord() {
		try {
			isStop = true;
			if (mediarecorder != null) {
				
				mediarecorder.stop();
				// time.setText(format(hour) + ":" + format(minute) + ":"
				// + format(second));
				
				mediarecorder.release();
				mediarecorder = null;
				if (mCamera != null) {
					mCamera.release();
					mCamera = null;
				}
				checkFiles();
				//Message msg=new Message();
				//msg.what=0;
				//msg.obj="停止录像了";
				//handlerAP.sendMessage(msg);
				//Up_down_fun.upload_video();
			
			}
		} catch (IllegalStateException e) {
			DirFile.err(e);
		}
	}

	
	public void stopRecord_2() {
		try {
			if (isStop == true) {
				isStop = false;
				if (mediarecorder != null) {
					
					mediarecorder.stop();
					// time.setText(format(hour) + ":" + format(minute) + ":"
					// + format(second));
					
					mediarecorder.release();
					mediarecorder = null;
					if (mCamera != null) {
						mCamera.release();
						mCamera = null;
					}
					checkFiles();
					BaseApplication.ts("重新开始");
				}
			} else {
				isStop = true;
				thread = new ThreadC(ms, surfaceview, surfaceHolder,
									 handlerAP,context);
				thread.start();
				//BaseApplication.ts("录像了");
			}
		} catch (IllegalStateException e) {
			DirFile.err(e);
		}
	}

	/**
	 * ��ʽ��ʱ��
	 */
	public String format(int i) {
		String s = i + "";
		if (s.length() == 1) {
			s = "0" + s;
		}
		return s;
	}

	/** * ��ʱ�� * @author bcaiw * */
	class TimerThread extends TimerTask {
		/** * ֹͣ¼�� */
		@Override
		public void run() {
			try {
				stopRecord();
				this.cancel();
				int il=PreferenceUtils.getPrefInt(BaseApplication.getContext(),"isLx",0);
				if(il==1){
				thread = new ThreadC(ms, surfaceview, surfaceHolder,
										 handlerAP,  context);
				thread.start();
				}
			} catch (Exception e) {
				//Err.err_ts(e);
				map.clear();
				map.put("recordingFlag", "false");
				String ac_time = getVedioRecordTime();// ¼��ʱ��
				map.put("recordTime", ac_time);

			}

		}
	}

	/**
	 * ͨ�÷��������ն��̹߳������ݣ��п��ܲ������msg�����Զ���map����
	 * 
	 * @param handle
	 * @param iType
	 * @param info
	 */
	public void sendMsgToHandle(Handler handle, int iType,
								Map<String, String> info) {
		Message threadMsg = handle.obtainMessage();
		threadMsg.what = iType;
		Bundle threadbundle = new Bundle();
		threadbundle.clear();
		for (Iterator<String> i = info.keySet().iterator(); i.hasNext();) {
			Object obj = i.next();
			threadbundle.putString(obj.toString(), info.get(obj));
		}
		threadMsg.setData(threadbundle);
		handle.sendMessage(threadMsg);

	}

	/**
	 * ���㵱ǰ��¼��ʱ�䣬Ĭ��ֵ����0
	 * 
	 * @return
	 */
	public String getVedioRecordTime() {
		String result = "0";
		if (startTime != Long.MIN_VALUE && endTime != Long.MIN_VALUE) {
			long tempTime = (endTime - startTime);
			result = String.valueOf(tempTime);
		}
		return result;

	}

	public void backStop() {
		mediarecorder.stop();
	}

	@SuppressLint("SimpleDateFormat")
	private static File getOutputMediaFile(int type) {
		// �ж�SDCard�Ƿ����
		// if (!Environment.MEDIA_MOUNTED.equals(Environment
		// .getExternalStorageState())) {
		// Log.d(TAG, "SDCard������");
		// return null;
		// }

		// File mediaStorageDir = new
		// File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
		// "MyCameraApp");
		// �������ͼƬ��Ӧ�ó���ж�غ󻹴��ڣ����ܱ�����Ӧ�ó�������˱���λ�������
		// �����ڵĻ����򴴽��洢Ŀ¼
		// File mediaStorageDir = new File(
		// Environment.getExternalStorageDirectory() + File.separator
		// + "/hx_camera/camera/");
		// if (!mediaStorageDir.exists()) {
		// if (!mediaStorageDir.mkdir()) {
		// //Log.d(TAG, "failed to create directory");
		// return null;
		// }
		// }
		// MyLog.writeTxtToFile("�����ļ���ʼ","","");
		File mediaFile = null;
		try {
			File mediaStorageDir = null;
			app_dir = DirFile.getVideoPath();
			//MyLog.writeTxtToFile("¼���ļ��У�"+app_dir,"","");
			String timestamp2 = new SimpleDateFormat("yyyyMMdd")
				.format(new Date());
			//MyLog.writeTxtToFile(timestamp2,"","");
			if (!wjm.equals("")) {// ����ļ�����ڣ�����
				wjm = timestamp2 + "_" + wjm;
				// mediaStorageDir=new File(app_dir + File.separator +
				// wjm+timestamp2+File.separator);
				mediaStorageDir = new File(app_dir + File.separator + wjm);
				//MyLog.writeTxtToFile("����","","");
			} else {
				mediaStorageDir = new File(app_dir);
			}

			if (!mediaStorageDir.exists()) {
				if (!mediaStorageDir.mkdirs()) {
					return null;
				}
			}

			// ����ý���ļ���yyyyMMdd_
			String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss")
				.format(new Date());
			//MyLog.writeTxtToFile(mediaStorageDir+"/"+timestamp,"","");
			if (type == MEDIA_TYPE_IMAGE) {
				mediaFile = new File(mediaStorageDir + File.separator + "IMG_"
									 + timestamp + ".jpg");
			} else if (type == MEDIA_TYPE_VIDEO) {

				mediaFile = new File(mediaStorageDir + File.separator
									 + timestamp + ".mp4");
			} else {
				//MyLog.writeTxtToFile("�ļ���������", "", "");
				return null;
			}
		} catch (Exception e) {
			//Err.err_ts(e);
			DirFile.err(e);
		}

		return mediaFile;
	}

	public void checkFiles() {
		// -------------------------
		new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						 
						String filePath1 = DirFile.getVideoPath();
						DirFile.del_file_by_size(filePath1,
												   (long) (nc * 1024 * 1024L));
					} catch (Exception e) {
						//Err.err_ts(e);
					}
				}
			}).start();
	}

}
