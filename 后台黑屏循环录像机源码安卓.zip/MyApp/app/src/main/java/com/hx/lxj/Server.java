package com.hx.lxj;

import android.annotation.*;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.hardware.*;
import android.os.*;
import android.os.PowerManager.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.WindowManager.*;
import android.widget.*;
import java.math.*;
import java.util.*;

import android.hardware.Camera;

public class Server extends Service implements SurfaceHolder.Callback {
	public static final String ACTION_BACK_HOME = "com.byd.recorder.ACTION_BACK_HOME";
	public static final String ACTION_SHOW_RECORDER = "com.byd.recorder.ACTION_SHOW_RECORDER";
	private static final int NOTIFICATION_DI = 1234;
	private WindowManager mWindowManager;
	private WindowManager.LayoutParams mLayoutParams;
	static SurfaceView mSurfaceView;
	LinearLayout relLay;
	static SurfaceHolder surfaceHolder;
	public static boolean islx2 = false;
	public static int islx1= 0;
	public int mKuan = 100;
	public int mSC = 15000;

	PowerManager powerManager = null;
	WakeLock wakeLock = null;
	public int issb=0;
	private LayoutInflater mInflater;
	public View sb;
	public int h=1;
	public Handler handlerAP=null;
	/**
	 * 拍摄
	 * 
	 * @param intent
	 * @return
	 */
	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}


	@SuppressWarnings("deprecation")
	@Override
	public void onCreate() {
		super.onCreate();
		islx1=PreferenceUtils.getPrefInt(BaseApplication.getContext(),"isLx",0);
		this.mKuan = PreferenceUtils.getPrefInt(this,"pinmodaxiao",300);
		this.mSC = PreferenceUtils.getPrefInt(this,"ms",60);
		this.mSC = mSC * 1000;// 毫秒
		powerManager = (PowerManager) this.getApplicationContext()
			.getSystemService(Context.POWER_SERVICE);
		wakeLock = this.powerManager.newWakeLock(PowerManager.FULL_WAKE_LOCK,
												 "My Lock");
		wakeLock.acquire();//亮屏
		handlerAP = new Handler() {
			@SuppressLint("HandlerLeak")
			public void handleMessage(Message msg) {
				if (msg.what == 0) {
String o=(String)msg.obj;
					BaseApplication.ts(o);
				}
			}
		};// handler
	}

	
	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {

		return super.onStartCommand(intent, flags, startId);
	}

	@SuppressLint("NewApi")
	@Override
	public void onStart(Intent intent, int startid) {
		//Toast.makeText(this, "开始", Toast.LENGTH_SHORT).show();
		Notification notification = new Notification.Builder(this)
			.setContentTitle("录像")
			.setContentText("后台运行")
			.setSmallIcon(R.drawable.ic_launcher)
			.setContentIntent(
			PendingIntent.getActivity(this, 0, new Intent(this,
														  WebView1.class), 0)).build();
		startForeground(NOTIFICATION_DI, notification);

		if (islx1 >=1) 
			{
			mWindowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
			//LayoutInflater.from(this).inflate(R.layout.lxj_ly_camera, null);
			mSurfaceView = new SurfaceView(this);
			surfaceHolder = mSurfaceView.getHolder();

			DisplayMetrics dm = getResources().getDisplayMetrics();
			int screenWidth = dm.widthPixels;
			int screenHeight = dm.heightPixels;
			
			/*WindowManager wm = (WindowManager) this 
				.getSystemService(Context.WINDOW_SERVICE); 
			int width = wm.getDefaultDisplay().getWidth(); 
			int height = wm.getDefaultDisplay().getHeight(); 
			double bl=height/width;*/
			//float bl = screenHeight / screenWidth;
			double bl= div(screenHeight,screenWidth,4);
			//BaseApplication.ts(bl+"");
			
			if (mKuan >= screenWidth||mKuan==600) {
				mKuan = screenWidth;
			}
			if (mKuan < 1) {
				mKuan = 1;
			}
			 h = (int) (mKuan * bl);
			if (h < 1) {
				h = 1;
			}
			if (mKuan < 1) {
				mKuan = 1;
			}
			LayoutParams params_sur = new LayoutParams();
			params_sur.width = mKuan;
			params_sur.height = h;
			params_sur.alpha = 255;
			mSurfaceView.setLayoutParams(params_sur);
			mSurfaceView.getHolder().addCallback(this);
			mLayoutParams = new WindowManager.LayoutParams();
			mLayoutParams.type = WindowManager.LayoutParams.TYPE_PHONE;
			mLayoutParams.format = 1;
			mLayoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
				| WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
			mLayoutParams.gravity = Gravity.CENTER_HORIZONTAL | Gravity.CENTER;
			// mLayoutParams.gravity =Gravity.LEFT|Gravity.TOP;

			mLayoutParams.x = 0;
			mLayoutParams.y = 0;
			// mLayoutParams.width = screenWidth;
			// mLayoutParams.height = screenHeight;
			mLayoutParams.width = mKuan;
			mLayoutParams.height = h;
			// mWindowManager.addView(mRecorderView, mLayoutParams);

			relLay = new LinearLayout(this);
			// LayoutParams params_rel = new LayoutParams();
			// params_rel.width = LayoutParams.WRAP_CONTENT;
			// params_rel.height = LayoutParams.WRAP_CONTENT;
			relLay.setLayoutParams(mLayoutParams);
			relLay.addView(mSurfaceView);
			mWindowManager.addView(relLay, mLayoutParams); // ����View
			mWindowManager.updateViewLayout(relLay, mLayoutParams);
			// MyLog.writeTxtToFile("�������","", "");
			//BaseApplication.ts("录制");
			mInflater = LayoutInflater.from(BaseApplication.getContext());
			 sb=mInflater.inflate(R.layout.seekbar, null);
			islx2 = true;
			relLay.setOnClickListener(new OnClickListener(){
					@Override
					public void onClick(View v){
						//
						if(issb==0){
						issb=1;
							LayoutParams mLayoutParams2=mLayoutParams;
						mLayoutParams2.width = LayoutParams.FILL_PARENT;
							mLayoutParams2.height=LayoutParams.WRAP_CONTENT;
							mLayoutParams2.gravity = Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM;
							
						mWindowManager.addView(sb,mLayoutParams2); 
						mWindowManager.updateViewLayout(sb, mLayoutParams);
					
							SeekBar seekbar = (SeekBar)sb.findViewById(R.id.seekbarSeekBar1);
							seekbar.setOnSeekBarChangeListener(
								new SeekBar.OnSeekBarChangeListener() {

									public void onStopTrackingTouch(SeekBar seekBar) {
										// TODO Auto-generated method stub
									}
									public void onStartTrackingTouch(SeekBar seekBar) {
										// TODO Auto-generated method stub
									}
									public void onProgressChanged(SeekBar seekBar, int progress,
																  boolean fromUser) {
										// TODO Auto-generated method stub
										int progress1 = progress/10;
											PreferenceUtils.setPrefInt(BaseApplication.getContext(),"fsu",progress1);
										Camera.Parameters p =ThreadC.mCamera.getParameters();
										p.setZoom(progress1);
										ThreadC.mCamera.setParameters(p);
									}
								}

							);
							//停止
							TextView tv=(TextView)sb.findViewById(R.id.seekbarTextView1);
							tv.setOnClickListener(new OnClickListener(){
									@Override
									public void onClick(View v){
										Intent intent = new Intent(BaseApplication.getContext(), MainActivity.class);
										 intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
										 intent.putExtra("action","stop");
										 PendingIntent pendingIntent =
										 PendingIntent.getActivity(BaseApplication.getContext(), 0, intent, 0);
										 try {
										 pendingIntent.send();
										 } catch (PendingIntent.CanceledException e) {
										 e.printStackTrace();
										 }
									}
							});
						}else{
							//BaseApplication.ts("123");
							mLayoutParams = new WindowManager.LayoutParams();
							mLayoutParams.type = WindowManager.LayoutParams.TYPE_PHONE;
							mLayoutParams.format = 1;
							mLayoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
								| WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
							mLayoutParams.gravity = Gravity.CENTER_HORIZONTAL | Gravity.CENTER;
							// mLayoutParams.gravity =Gravity.LEFT|Gravity.TOP;

							mLayoutParams.x = 0;
							mLayoutParams.y = 0;
							// mLayoutParams.width = screenWidth;
							// mLayoutParams.height = screenHeight;
							mLayoutParams.width = mKuan;
							mLayoutParams.height = h;
							
							issb=0;
							mWindowManager.removeView(sb);
							mWindowManager.updateViewLayout(relLay, mLayoutParams);
						}
						
					}
			});
		}// islx
	}
	
	/**
	 * 提供（相对）精确的除法运算。当发生除不尽的情况时，由scale参数指
	 * 定精度，以后的数字四舍五入。
	 * @param v1 被除数
	 * @param v2 除数
	 * @param scale 表示表示需要精确到小数点以后几位。
	 * @return 两个参数的商
	 */
	public static double div(double v1, double v2, int scale) {
		if (scale < 0) {
			throw new IllegalArgumentException(
                "The scale must be a positive integer or zero");
		}
		BigDecimal b1 = new BigDecimal(Double.toString(v1));
		BigDecimal b2 = new BigDecimal(Double.toString(v2));
		return b1.divide(b2, scale, BigDecimal.ROUND_HALF_UP).doubleValue();
	}
	/**
	 * �������ʱ�Ļص�
	 */
	@SuppressWarnings("deprecation")
	@Override
	public void onDestroy() {

		try {
			mWindowManager.removeView(relLay);
			islx2 = false;
			ThreadC thread = ThreadC.thread;
			
			if (thread != null) {
				thread.isStop = false;
				thread.stopRecord();
				thread.stop(); 
				//BaseApplication.ts("停止");
			}
		} catch (Exception e) {
			//Err.getErrStr(e);
			DirFile.err(e);
		}
		super.onDestroy();
	}
	
	public static void stop(){
		ThreadC thread = ThreadC.thread;
islx1=0;
		if (thread != null) {
			thread.isStop = false;
			thread.stopRecord();
			thread.stop(); 
			//BaseApplication.ts("停止录像");
		}
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int arg1, int arg2,
							   int arg3) {
		// TODO �Զ���ɵķ������
		surfaceHolder = holder;
		//BaseApplication.ts("surfaceChanged");
		// MyLog.writeTxtToFile("surfaceChanged", "", "");
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		try {
			surfaceHolder = holder;
			ThreadC thread = new ThreadC(mSC, mSurfaceView, surfaceHolder, handlerAP,this);
			thread.start();
			BaseApplication.ts("新建录像");
		} catch (Exception e) {
			DirFile.err(e);
			//Err.getErrStr(e);
			// MyLog.writeTxtToFile("server:"+e.toString(), "", "");
		}
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder arg0) {
		mSurfaceView = null;
		surfaceHolder = null;
		islx2 = false;
		//BaseApplication.ts("");
	}
	//-----------------------------------------
	public boolean onTouchEvent(MotionEvent event) {
		if (event.getPointerCount() == 1) {
			handleFocusMetering(event, ThreadC.mCamera);
		} else {
			float oldDist = 0;
			switch (event.getAction() & MotionEvent.ACTION_MASK) {
				case MotionEvent.ACTION_POINTER_DOWN:
					oldDist = getFingerSpacing(event);
					break;
				case MotionEvent.ACTION_MOVE:
					float newDist = getFingerSpacing(event);
					if (newDist > oldDist) {

						handleZoom(true, ThreadC.mCamera);
					} else if (newDist < oldDist) {

						handleZoom(false, ThreadC.mCamera);
					}
					oldDist = newDist;
					break;
			}
		}
		return true;
	}

	private void handleZoom(boolean isZoomIn, Camera camera) {

		Camera.Parameters params = camera.getParameters();
		if (params.isZoomSupported()) {
			int maxZoom = params.getMaxZoom();
			int zoom = params.getZoom();
			if (isZoomIn && zoom < maxZoom) {

				zoom++;
			} else if (zoom > 0) {

				zoom--;
			}
			params.setZoom(zoom);
			camera.setParameters(params);
		} else {

		}
	}

	private static void handleFocusMetering(MotionEvent event, Camera camera) {

		Camera.Parameters params = camera.getParameters();
		Camera.Size previewSize = params.getPreviewSize();
		Rect focusRect = calculateTapArea(event.getX(), event.getY(), 1f, previewSize);
		Rect meteringRect = calculateTapArea(event.getX(), event.getY(), 1.5f, previewSize);

		camera.cancelAutoFocus();

		if (params.getMaxNumFocusAreas() > 0) {
			List<Camera.Area> focusAreas = new ArrayList<Camera.Area>();
			focusAreas.add(new Camera.Area(focusRect, 800));
			params.setFocusAreas(focusAreas);
		} else {

		}
		if (params.getMaxNumMeteringAreas() > 0) {
			List<Camera.Area> meteringAreas = new ArrayList<Camera.Area>();
			meteringAreas.add(new Camera.Area(meteringRect, 800));
			params.setMeteringAreas(meteringAreas);
		} else {

		}
		final String currentFocusMode = params.getFocusMode();
		params.setFocusMode(Camera.Parameters.FOCUS_MODE_MACRO);
		camera.setParameters(params);

		camera.autoFocus(new Camera.AutoFocusCallback() {
	            @Override
	            public void onAutoFocus(boolean success, Camera camera) {
	                Camera.Parameters params = camera.getParameters();
	                params.setFocusMode(currentFocusMode);
	                camera.setParameters(params);
	            }
	        });
	}

	private static float getFingerSpacing(MotionEvent event) {
		float x = event.getX(0) - event.getX(1);
		float y = event.getY(0) - event.getY(1);

		return (float) Math.sqrt(x * x + y * y);
	}

	private static Rect calculateTapArea(float x, float y, float coefficient, Camera.Size previewSize) {
		float focusAreaSize = 300;
		int areaSize = Float.valueOf(focusAreaSize * coefficient).intValue();
		int centerX = (int) (x / previewSize.width - 1000);
		int centerY = (int) (y / previewSize.height - 1000);

		int left = clamp(centerX - areaSize / 2, -1000, 1000);
		int top = clamp(centerY - areaSize / 2, -1000, 1000);

		RectF rectF = new RectF(left, top, left + areaSize, top + areaSize);

		return new Rect(Math.round(rectF.left), Math.round(rectF.top), Math.round(rectF.right), Math.round(rectF.bottom));
	}

	private static int clamp(int x, int min, int max) {
		if (x > max) {
			return max;
		}
		if (x < min) {
			return min;
		}
		return x;
	}
	//-----------------------------------------
	
	
}
