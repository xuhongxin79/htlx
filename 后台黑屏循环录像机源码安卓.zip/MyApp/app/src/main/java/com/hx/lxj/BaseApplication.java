package com.hx.lxj;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.content.pm.PackageManager.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.util.*;

public class BaseApplication extends Application {
	private static final int NOTIFICATIONID = 3890;
	static Context mContext;
	private List<Activity> oList;// 活动们

	@Override
	public void onCreate() {
		super.onCreate();
		BaseApplication.mContext = this;
		CrashHandler crashHandler = CrashHandler.getInstance();
		crashHandler.init(this);
		oList = new ArrayList<Activity>();
		// Toast.makeText(mContext, "BaseApplication",
		// Toast.LENGTH_SHORT).show();
	}

	/**
	 * 添加活动
	 */
	public void addActivity_(Activity activity) {
		//
		if (!oList.contains(activity)) {
			oList.add(activity);
		}
	}

	/**
	 * 删除活动
	 */
	public void removeActivity_(Activity activity) {
		
		if (oList.contains(activity)) {
			oList.remove(activity);// �Ӽ������Ƴ�
			activity.finish();// ��ٵ�ǰActivity
		}
	}

	/**
	 * 删除Activity
	 */
	public void removeALLActivity_() {
		
		for (Activity activity : oList) {
			activity.finish();
		}
	}
	//版本
	public static String getVersion() {
		Context context = getInstance();
		String packageName = context.getPackageName();
		try {
			PackageManager pm = context.getPackageManager();
			return pm.getPackageInfo(packageName, 0).versionName;
		} catch (NameNotFoundException e) {
			return null;
		}
	}
	//Context
	public static Context getContext() {
		return mContext;
	}
//实例
	public static BaseApplication getInstance() {
		return (BaseApplication) mContext;
	}

	// 提示
	public static void ts(String str) {
		Toast.makeText(mContext, str, Toast.LENGTH_LONG).show();
	}

	// 包名
	public static String get_pack_name() {
		String pkn = mContext.getPackageName().toString();
		return pkn;
	}
	
	
	/**
     * 通过网络接口取
     * @return
     */
    public static String getNewMac() {
        try {
            List<NetworkInterface> all = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface nif : all) {
                if (!nif.getName().equalsIgnoreCase("wlan0")) continue;

                byte[] macBytes = nif.getHardwareAddress();
                if (macBytes == null) {
                    return null;
                }

                StringBuilder res1 = new StringBuilder();
                for (byte b : macBytes) {
                    res1.append(String.format("%02X:", b));
                }

                if (res1.length() > 0) {
                    res1.deleteCharAt(res1.length() - 1);
                }
                return res1.toString();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
	
}
