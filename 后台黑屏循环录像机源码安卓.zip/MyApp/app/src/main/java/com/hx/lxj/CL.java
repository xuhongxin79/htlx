package com.hx.lxj;

public class CL
{
	public static String APPDIRKEY="appdir";
	public static String ZCMKEY="zcm";
	public static String KLKEY1="kl1";
	public static String KLKEY2="kl2";
	}
