package com.hx.lxj;

import java.util.ArrayList;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class Receiver extends BroadcastReceiver {
	@Override
	public void onReceive(Context context, Intent intent) {

		if (!isServiceRunning(context, "com.hx.lxj.Server")) {
			Toast.makeText(context, "循环检查", Toast.LENGTH_SHORT).show();
			Intent intent2 = new Intent(context, Server.class);
			context.startService(intent2);
		}
		
	}

	public static boolean isServiceRunning(Context context, String ServiceName) {
		if (("").equals(ServiceName) || ServiceName == null)
			return false;
		ActivityManager myManager = (ActivityManager) context
			.getSystemService(Context.ACTIVITY_SERVICE);
		ArrayList<RunningServiceInfo> runningService = (ArrayList<RunningServiceInfo>) myManager
			.getRunningServices(30);
		for (int i = 0; i < runningService.size(); i++) {
			if (runningService.get(i).service.getClassName().toString()
				.equals(ServiceName)) {
				return true;
			}
		}
		return false;
	}
}
